import { registerRootComponent } from 'expo';
import AppNavigator from './AppNavigator';

registerRootComponent(AppNavigator);