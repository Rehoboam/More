import { registerRootComponent } from 'expo';
import Main from './Main';

registerRootComponent(Main);