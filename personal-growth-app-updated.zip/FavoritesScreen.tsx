import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { getFavorites } from './src/utils/favorites';
import { getLessonById } from './src/utils/lessons';

const USER_ID = 'demo-user';

export default function FavoritesScreen() {
  const [lessons, setLessons] = useState([]);

  useEffect(() => {
    async function fetch() {
      const ids = await getFavorites(USER_ID);
      const all = await Promise.all(ids.map(id => getLessonById(id)));
      setLessons(all.filter(Boolean));
    }
    fetch();
  }, []);

  return (
    <ScrollView style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20 }}>❤️ Favorite Lessons</Text>
      {lessons.length === 0 && <Text>No favorites yet.</Text>}
      {lessons.map((lesson, index) => (
        <View key={index} style={{ marginBottom: 24 }}>
          <Text style={{ fontWeight: 'bold', fontSize: 18 }}>{lesson.title}</Text>
          <Text style={{ marginBottom: 4 }}>{lesson.topic}</Text>
          <Text style={{ color: '#555' }}>{lesson.content}</Text>
        </View>
      ))}
    </ScrollView>
  );
}