import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://flbbvkrzrfiacfuzkekn.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZsYmJ2a3J6cmZpYWNmdXprZWtuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk3NTg3NDEsImV4cCI6MjA2NTMzNDc0MX0.sp8DnqoxIPCaNDLRCZxCSSL8uQpGWUMzIJug5rBzxLU';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);