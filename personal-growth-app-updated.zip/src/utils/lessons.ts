import { supabase } from '../lib/supabase';

export async function getTodayLesson() {
  const today = new Date().getDate();
  const { data, error } = await supabase
    .from('daily_lessons')
    .select('*')
    .range(today, today)
    .limit(1);

  if (error) {
    console.error('Supabase error:', error);
    return null;
  }

  return data[0];
}