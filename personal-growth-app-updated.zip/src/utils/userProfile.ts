import { supabase } from './supabaseClient';

const TABLE = 'user_profiles';

export async function getUserProfile(userId: string) {
  const { data } = await supabase
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .single();
  return data;
}

export async function setUserProfile(userId: string, updates: {
  interests?: string[];
  goals?: string[];
  preferred_tone?: string;
}) {
  const { data, error } = await supabase
    .from(TABLE)
    .upsert({
      user_id: userId,
      ...updates
    });
  return { data, error };
}