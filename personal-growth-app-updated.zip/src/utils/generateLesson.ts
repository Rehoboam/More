import { openai } from './openaiClient';
import { getUserProfile } from './userProfile';

export async function generateLesson(userId: string) {
  const profile = await getUserProfile(userId);
  if (!profile) return null;

  const prompt = `
You are an expert personal growth coach. Create a short micro-learning lesson for someone interested in:
- Interests: ${profile.interests?.join(', ') || 'general personal growth'}
- Goals: ${profile.goals?.join(', ') || 'self-improvement'}
- Tone: ${profile.preferred_tone || 'motivational'}

Respond in JSON format like:
{
  "title": "",
  "topic": "",
  "content": "",
  "action": "",
  "reflection": ""
}`;

  const res = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.7
  });

  const text = res.choices?.[0]?.message?.content;
  return JSON.parse(text);
}