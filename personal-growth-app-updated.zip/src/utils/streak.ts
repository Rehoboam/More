import { supabase } from './supabaseClient';
import { getTodayDate } from './utils';

const STREAK_TABLE = 'user_streaks';

export async function updateStreak(userId: string) {
  const today = getTodayDate();
  const yesterday = getTodayDate(-1);

  const { data, error } = await supabase
    .from(STREAK_TABLE)
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching streak:', error.message);
    return;
  }

  if (!data) {
    await supabase.from(STREAK_TABLE).insert({
      user_id: userId,
      last_completed_date: today,
      current_streak: 1,
      max_streak: 1
    });
    return;
  }

  const { last_completed_date, current_streak, max_streak } = data;

  if (last_completed_date === today) return; // already done

  const isConsecutive = last_completed_date === yesterday;
  const newStreak = isConsecutive ? current_streak + 1 : 1;

  await supabase.from(STREAK_TABLE).update({
    last_completed_date: today,
    current_streak: newStreak,
    max_streak: Math.max(max_streak, newStreak)
  }).eq('user_id', userId);
}

export async function getStreak(userId: string) {
  const { data } = await supabase
    .from(STREAK_TABLE)
    .select('*')
    .eq('user_id', userId)
    .single();
  return data?.current_streak || 0;
}