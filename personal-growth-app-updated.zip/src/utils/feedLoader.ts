import { supabase } from './supabaseClient';
import { generateMicroFeed } from './generateMicroFeed';

const TABLE = 'micro_feed';

export async function loadOrGenerateMicroFeed(userId: string) {
  const today = new Date().toISOString().split('T')[0];

  const { data: existing } = await supabase
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .single();

  if (existing) return existing;

  const items = await generateMicroFeed(userId);

  const { data } = await supabase
    .from(TABLE)
    .insert({
      user_id: userId,
      date: today,
      items
    })
    .select()
    .single();

  return data;
}