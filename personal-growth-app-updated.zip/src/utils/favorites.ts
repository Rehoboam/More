import { supabase } from './supabaseClient';

const FAVORITES_TABLE = 'user_favorites';

export async function toggleFavorite(userId: string, lessonId: string, isFavorite: boolean) {
  if (isFavorite) {
    await supabase.from(FAVORITES_TABLE).insert({
      user_id: userId,
      lesson_id: lessonId,
      favorited_at: new Date().toISOString()
    });
  } else {
    await supabase.from(FAVORITES_TABLE)
      .delete()
      .eq('user_id', userId)
      .eq('lesson_id', lessonId);
  }
}

export async function getFavorites(userId: string) {
  const { data } = await supabase
    .from(FAVORITES_TABLE)
    .select('lesson_id');
  return data?.map(item => item.lesson_id) || [];
}