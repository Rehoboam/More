import { supabase } from './supabaseClient';
import { generateLesson } from './generateLesson';

const TABLE = 'lessons';

export async function loadOrGenerateLesson(userId: string) {
  const today = new Date().toISOString().split('T')[0]; // yyyy-mm-dd

  const { data: existing } = await supabase
    .from(TABLE)
    .select('*')
    .eq('user_id', userId)
    .eq('date', today)
    .single();

  if (existing) return existing;

  const newLesson = await generateLesson(userId);

  const { data } = await supabase
    .from(TABLE)
    .insert({
      user_id: userId,
      date: today,
      ...newLesson
    })
    .select()
    .single();

  return data;
}