import { openai } from './openai';
import { getUserProfile } from './userProfile';

export async function generateMicroFeed(userId: string) {
  const profile = await getUserProfile(userId);
  const tone = profile?.preferred_tone || 'motivational';
  const interests = profile?.interests?.join(', ') || 'growth, discipline';

  const prompt = \`
You're a personal growth assistant. Based on the user's interests: \${interests}, and tone: \${tone}, generate 5 brief insights for today.

Each should be:
- 1–2 sentences
- Standalone (quote, fact, or mindset tip)
- In the tone: \${tone}

Output only JSON array of strings.
\`;

  const response = await openai.chat.completions.create({
    messages: [{ role: 'user', content: prompt }],
    model: 'gpt-4o',
    temperature: 0.8
  });

  const content = response.choices?.[0]?.message?.content || '[]';
  const items = JSON.parse(content);
  return items;
}