import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Picker } from 'react-native';
import { getUserProfile, setUserProfile } from './utils/userProfile';

const ProfileScreen = () => {
  const userId = 'demo-user';
  const [interests, setInterests] = useState('');
  const [goals, setGoals] = useState('');
  const [preferredTone, setPreferredTone] = useState('motivational');

  useEffect(() => {
    async function loadProfile() {
      const data = await getUserProfile(userId);
      if (data) {
        setInterests(data.interests?.join(', ') || '');
        setGoals(data.goals?.join(', ') || '');
        setPreferredTone(data.preferred_tone || 'motivational');
      }
    }
    loadProfile();
  }, []);

  const handleSave = async () => {
    await setUserProfile(userId, {
      interests: interests.split(',').map(s => s.trim()),
      goals: goals.split(',').map(s => s.trim()),
      preferred_tone: preferredTone
    });
    alert('Profile saved!');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Interests</Text>
      <TextInput value={interests} onChangeText={setInterests} style={styles.input} />

      <Text style={styles.label}>Goals</Text>
      <TextInput value={goals} onChangeText={setGoals} style={styles.input} />

      <Text style={styles.label}>Preferred Tone</Text>
      <Picker
        selectedValue={preferredTone}
        style={styles.input}
        onValueChange={(itemValue) => setPreferredTone(itemValue)}
      >
        <Picker.Item label="Motivational" value="motivational" />
        <Picker.Item label="Gentle" value="gentle" />
        <Picker.Item label="Direct" value="direct" />
      </Picker>

      <Button title="Save" onPress={handleSave} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 24
  },
  label: {
    fontWeight: 'bold',
    marginTop: 16
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    marginTop: 4
  }
});

export default ProfileScreen;