import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ActivityIndicator, ScrollView } from 'react-native';
import { loadOrGenerateLesson } from './src/utils/lessonLoader';

export default function App() {
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const userId = 'demo-user'; // Replace with real auth later

  useEffect(() => {
    async function fetchLesson() {
      const data = await loadOrGenerateLesson(userId);
      setLesson(data);
      setLoading(false);
    }
    fetchLesson();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#888" />
        <Text>Loading your personalized lesson...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>{lesson.title}</Text>
      <Text style={styles.topic}>{lesson.topic}</Text>
      <Text style={styles.content}>{lesson.content}</Text>
      <Text style={styles.action}>🎯 {lesson.action}</Text>
      <Text style={styles.reflection}>🪞 {lesson.reflection}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  container: {
    padding: 24
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8
  },
  topic: {
    fontSize: 16,
    fontStyle: 'italic',
    marginBottom: 12
  },
  content: {
    fontSize: 16,
    marginBottom: 16
  },
  action: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12
  },
  reflection: {
    fontSize: 16,
    color: '#555'
  }
});